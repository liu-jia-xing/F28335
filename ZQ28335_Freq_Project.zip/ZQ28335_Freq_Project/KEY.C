/********************************************************************
* �ļ�����  ����ɨ�����
* ����:   ���г��򣬰��°������۲����Key��ֵ����ֵ�Ӵ�1~9,�޼�����ʱΪ0)��
*       ���߱�ţ�1-3��δ����ʱ���Ϊ0
*       ���߱�ţ�1-3��δ����ʱ���Ϊ0
* ���ú���: ReadKey();

* ʹ����Դ��
* ����KX1~KX3������F28335��GPI053~GPI051
* ����KY1~KY3������F28335��GPI050~GPI048

**********************************************************************/
/********************************************************************
����˵��������ɨ��ԭ����1��3�ж�Ӧ��IO����Ϊ���,3�ж�Ӧ��IO����Ϊ���롣
                2�����ް������£�3������IO����Ϊ�ߵ�ƽ����Ϊ���ⲿ�������裩
                3�����������£���Ӧ��IO�����ͣ�����Ϊ��X�У������Ϊ�͵�ƽ�����������У�X�У��������������
                4����ʱ�����θı�3�е����Ϊ�ߣ�����������������ʱ����X�е�ƽ���±�Ϊ�ߡ����������С������������
********************************************************************/

#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File
#include "GUI.h"               // LED״̬�궨��
#include "Delay.h"
#include "KEY.h"
#include "LED_M.h"               // LED״̬�궨��
#include "LED.h"
/**************************************�궨��************************************************/
#define SET_KY4         GpioDataRegs.GPASET.bit.GPIO23 = 1                      //Y4����
#define SET_KY3         GpioDataRegs.GPASET.bit.GPIO24 = 1                      //Y3����
#define SET_KY2         GpioDataRegs.GPASET.bit.GPIO25 = 1                      //Y2����
#define SET_KY1         GpioDataRegs.GPASET.bit.GPIO26 = 1                      //Y1����

#define RST_KY4         GpioDataRegs.GPACLEAR.bit.GPIO23 = 1                        //Y4����
#define RST_KY3         GpioDataRegs.GPACLEAR.bit.GPIO24 = 1                    //Y3����
#define RST_KY2         GpioDataRegs.GPACLEAR.bit.GPIO25 = 1                    //Y2����
#define RST_KY1          GpioDataRegs.GPACLEAR.bit.GPIO26 = 1                    //Y1����

#define KX4_STATUS      GpioDataRegs.GPADAT.bit.GPIO27                          //X4״̬
#define KX3_STATUS      GpioDataRegs.GPADAT.bit.GPIO28                          //X3״̬
#define KX2_STATUS      GpioDataRegs.GPADAT.bit.GPIO29                          //X2״̬
#define KX1_STATUS      GpioDataRegs.GPADAT.bit.GPIO30                          //X1״̬
/*****************************************************************************************************/

/**************************************��������************************************************/
Uint16 Keys[4][4] = {1,2,3,10, 4,5,6,11, 7,8,9,12, 13,0,14,15};//���ݱ�����16��������Ӧ
Uint16 Key = 255;                                             //ʵʱ������Ϣ����
Uint16 KX_On = 0;        //���߱�ţ�δ����ʱ���Ϊ0,�а��·ֱ�Ϊ1-3��
Uint16 KY_On = 0;        //���߱�ţ�δ����ʱ���Ϊ0,�а��·ֱ�Ϊ1-3��
Uint16 KX_Status[5]={0};     // KX_Status[4]--->KX4״̬�� KX_Status[0]δʹ��

/*********************************************��������************************************************/
void InitKeyGpio(void);  // ��ʼ����������
void delay(Uint32 t);
void RstAllKY(void);   // ������������ΪL��ƽ
void GetKX(void);      // �õ�����״̬
void GetKX_On(void);   // �õ��������������б��
void SetKY(Uint16 y);  // ����ָ������ΪH��ƽ
void RstKY(Uint16 y);  // ����ָ������ΪL��ƽ
void GetKey(void);     // �õ����µİ�����ţ�����Key��


/*********************************************��������**************************************************/

/*******************************����IO��ʼ��***********************************/
void InitKeyGpio(void)
{

    EALLOW;

    //////////////////////////////�����ĸ�IO������Ϊ�������Ϊ��ɨ��////////////////////////////

    //KY4: ��ӦPCB���� KEY_MATRIX��IO23
    GpioCtrlRegs.GPAPUD.bit.GPIO23 = 0;                                     // Enable pullup on GPIO11
    GpioDataRegs.GPASET.bit.GPIO23 = 1;                                     // Load output latch
    GpioCtrlRegs.GPAMUX2.bit.GPIO23 = 0;                                    // GPIO11 = GPIO
    GpioCtrlRegs.GPADIR.bit.GPIO23 = 1;                                     // GPIO11 = output

    //KY3: ��ӦPCB���� KEY_MATRIX��IO24
    GpioCtrlRegs.GPAPUD.bit.GPIO24 = 0;                                     // Enable pullup on GPIO11
    GpioDataRegs.GPASET.bit.GPIO24 = 1;                                     // Load output latch
    GpioCtrlRegs.GPAMUX2.bit.GPIO24 = 0;                                    // GPIO11 = GPIO
    GpioCtrlRegs.GPADIR.bit.GPIO24 = 1;                                     // GPIO11 = output

    //KY2: ��ӦPCB���� KEY_MATRIX��IO25
    GpioCtrlRegs.GPAPUD.bit.GPIO25 = 0;                                     // Enable pullup on GPIO11
    GpioDataRegs.GPASET.bit.GPIO25 = 1;                                     // Load output latch
    GpioCtrlRegs.GPAMUX2.bit.GPIO25 = 0;                                    // GPIO11 = GPIO
    GpioCtrlRegs.GPADIR.bit.GPIO25 = 1;                                     // GPIO11 = output

    //KY1: ��ӦPCB���� KEY_MATRIX��IO26
    GpioCtrlRegs.GPAPUD.bit.GPIO26 = 0;                                     // Enable pullup on GPIO11
    GpioDataRegs.GPASET.bit.GPIO26 = 1;                                     // Load output latch
    GpioCtrlRegs.GPAMUX2.bit.GPIO26 = 0;                                    // GPIO11 = GPIO
    GpioCtrlRegs.GPADIR.bit.GPIO26 = 1;                                     // GPIO11 = output


    //////////////////////////////�����ĸ�IO������Ϊ���룬��Ϊ��ɨ��////////////////////////////

    //KX4: ��ӦPCB���� KEY_MATRIX��IO27
    GpioCtrlRegs.GPAPUD.bit.GPIO27 = 0;                                     // Enable pullup on GPIO11
    GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 0;                                    // ����Ϊһ��IO��
    GpioCtrlRegs.GPADIR.bit.GPIO27  = 0;                                    // IO�ڷ���Ϊ����

    //KX3: ��ӦPCB���� KEY_MATRIX��IO28
    GpioCtrlRegs.GPAPUD.bit.GPIO28 = 0;                                     // Enable pullup on GPIO11
    GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 0;                                    // ����Ϊһ��IO��
    GpioCtrlRegs.GPADIR.bit.GPIO28  = 0;                                    // IO�ڷ���Ϊ����

    //KX2: ��ӦPCB���� KEY_MATRIX��IO29
    GpioCtrlRegs.GPAPUD.bit.GPIO29 = 0;                                     // Enable pullup on GPIO11
    GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 0;                                    // ����Ϊһ��IO��
    GpioCtrlRegs.GPADIR.bit.GPIO29  = 0;                                    // IO�ڷ���Ϊ����

    //KX1: ��ӦPCB���� KEY_MATRIX��IO30
    GpioCtrlRegs.GPAPUD.bit.GPIO30 = 0;                                     // Enable pullup on GPIO11
    GpioCtrlRegs.GPAMUX2.bit.GPIO30  = 0;                                   // ����Ϊһ��IO��
    GpioCtrlRegs.GPADIR.bit.GPIO30   = 0;                                       // IO�ڷ���Ϊ����

    EDIS;
    RstAllKY();
}


/*********************************************��ʱ����************************************************/
void delay(Uint32 t)
{
    Uint32 i = 0;
    for (i = 0; i < t; i++);
}
/*****************************************************************************************************/

/****************************************4��ȫ������͵�ƽ************************************************/
void RstAllKY(void)
{
    RST_KY4 ;
    RST_KY3 ;
    RST_KY2 ;
    RST_KY1 ;
}
/*****************************************************************************************************/

/****************************************��ȡ4��IO��ƽ״̬************************************************/
void GetKX(void)
{
    Uint16 x;           // �����
    Uint16 temp[5];     // temp[0]��ʹ��

    //��ȡ�������ߵ�ƽֵ���޼�����ʱKX_Status[1~3]��Ϊ1
    // Ϊ�˰���������������Ρ�
    KX_Status[1] = KX1_STATUS;
    KX_Status[2] = KX2_STATUS;
    KX_Status[3] = KX3_STATUS;
    KX_Status[4] = KX4_STATUS;

    for (x=1;x<5;x++)
    {
        temp[x]=KX_Status[x];
    }
    delay(200);  // �Ե�

    //Ϊ���������ٴζ�ȡ�������ߵ�ƽֵ
    KX_Status[1] = KX1_STATUS;
    KX_Status[2] = KX2_STATUS;
    KX_Status[3] = KX3_STATUS;
    KX_Status[4] = KX4_STATUS;

    for (x=1;x<5;x++)
    {
        if (temp[x]!=KX_Status[x]) // ���μ�ⲻͬ����δ���´�������ΪH
            KX_Status[x]=1;
    }
}
/*****************************************************************************************************/

/**************************************��ȡ������λ��**************************************/
// �жϰ��������У���¼�б��1~3�ڱ���KX_On�У����ް������£���KX_On=0��
void GetKX_On(void)
{
    Uint16 x;   // �����


    GetKX();  // �õ�����״̬

    //  �ӵ�1~3�������ж��Ƿ��м�����
    for (x=1;x<5;x++)
    {
        if(KX_Status[x] == 0)   // ��ָ�������м�����
        {
            KX_On = x;          // ��¼�м����µ����߱�ţ������һ��λ��
        }
    }
}
/*****************************************************************************************************/

/*******************************ָ��������ߵ�ƽ******************************************/
void Set_KY(Uint16 y)
{
    if(y==1){SET_KY1;}
    if(y==2){SET_KY2;}
    if(y==3){SET_KY3;}
    if(y==4){SET_KY4;}
}
/*****************************************************************************************************/

/*******************************ָ��������͵�ƽ**********************************************/
void Rst_KY(Uint16 y)
{
    if(y==1){RST_KY1;}
    if(y==2){RST_KY2;}
    if(y==3){RST_KY3;}
    if(y==4){RST_KY4;}
}
/*****************************************************************************************************/

/*******************************��ȡ������λ��**********************************************/
// ���а������µ��б��KY_On�Ͱ������Key
void GetKY_On(void)
{
    Uint16 y;       // �����

    if (KX_On==0)  // û�а�������
    {
        KY_On=0;
    }
    else
    {
        for (y=1;y<5;y++) //���м��
        {
            Set_KY(y);     // ����xָ������ΪH
            delay(2000);       // ��һ�ȣ���ָ��������H������

            GetKX();      // ����������ֵ��˵����ֻ��ָ����KX_On�м��ɣ����ﲻ������д������
            if(KX_Status[KX_On])  // ���ָ��KX_On�е�ƽΪH
            {
                KY_On = y;        // �õ������
            }
            Rst_KY(y);            // �ָ�L��ƽ

            if (KY_On!=0)  break;

        }
    }
}
/*****************************************************************************************************/


/*****************************************************************************************************/
void GetKey(void)
{
    Key=255;
    KX_On=0;
    KY_On=0;

    RstAllKY();   // ������������ΪL
    GetKX_On();   // �õ��������߱�ţ�����KX_On��

    if (KX_On!=0)    // �м�����
    {
        GetKY_On();   // �õ��������߱�ţ�����KY_On��
        Key = Keys[KX_On-1][KY_On-1];   // ��ѯ����ֵ
    }

}
/****************************************************************************/
//��������ģ�鲿��

unsigned char MenuFlag = 0;         //�˵�״̬��־λ
unsigned char SubSel_Flag = 0;      //�Ӳ˵�ѡ���־

unsigned char Sub_Flag1=0;          //�Ӳ˵�1��ֵ�����л���־λ
unsigned char Sub_Flag2=0;          //�Ӳ˵�2��ֵ�����л���־λ
unsigned char Sub_Flag3=0;          //�Ӳ˵�3��ֵ�����л���־λ
unsigned char Sub_Flag4=0;          //�Ӳ˵�4��ֵ�����л���־λ
unsigned char Sub_position1=0;
unsigned char Sub_position2=0;
unsigned char Sub_position4=0;
unsigned char Sub_position3=0;
//��Ƶ��������
typedef struct Val
{
    unsigned long frequency_1;
    unsigned long frequency_2;
    unsigned int phase_1;
    unsigned int phase_2;
}val_dat;
unsigned int Val1=0;
typedef struct Val2
{
    unsigned long frequency_MAX;
    unsigned long frequency_MIN;
    unsigned long step;
}val2;
val2 SubSel3;
val2 SubSel4;
val_dat SubSel1;

void data_init()
{
    SubSel1.frequency_1=0;    //I·Ƶ�ʣ���λ
    SubSel1.frequency_2=0;
    SubSel1.phase_1=0;        //Q·Ƶ�ʣ���λ
    SubSel1.phase_2=0;
    SubSel3.frequency_MAX=0;
    SubSel3.frequency_MIN=0;
    SubSel3.step=0;
    SubSel4.frequency_MAX=0;
    SubSel4.frequency_MIN=0;
    SubSel4.step=0;
}
void Key0Fun(void)
{
    if(MenuFlag==1)
        {
            if(SubSel_Flag==1)
            {
                switch(Sub_Flag1%4)
                {
                case 1:
                    Gui_DrawFont_GBK16(142+Sub_position1*8,67,BLACK,GRAY0,"0");
                    //�����ۼ�
                    SubSel1.frequency_1*=10;
                    SubSel1.frequency_1+=1;
                    break;
                case 2:
                    Gui_DrawFont_GBK16(142+Sub_position1*8,107,BLACK,GRAY0,"0");
                    //��λ���
                    SubSel1.phase_1*=10;
                    SubSel1.phase_1+=1;
                    break;
                case 3:
                    Gui_DrawFont_GBK16(142+Sub_position1*8,147,BLACK,GRAY0,"0");
                    SubSel1.frequency_2*=10;
                    SubSel1.frequency_2+=1;
                    break;
                case 0:
                    Gui_DrawFont_GBK16(142+Sub_position1*8,187,BLACK,GRAY0,"0");
                    if(Sub_position1<=2)
                    {
                        SubSel1.phase_2*=10;
                        SubSel1.phase_2+=1;
                    }
                    break;
                default:break;
                }

                //�����жϸ���������ĳ���  Ƶ�����볤����9 ��λ�ĳ�����3
                if(Sub_Flag1%4==0||Sub_Flag1%4==2){
                    if(Sub_position1<2)
                        Sub_position1++;}
                else
                {
                    if(Sub_position1<=9)
                        Sub_position1++;
                }
            }
            //�Ӳ˵�������
            if(SubSel_Flag==2)
            {
                Gui_DrawFont_GBK16(142+Sub_position2*8,87,BLACK,GRAY0,"0");
                if(Sub_position2<9)
                {
                    Val1*=10;
                    Val1+=1;
                    Sub_position2++;
                }
            }
            if(SubSel_Flag==3)
            {
                switch(Sub_Flag3%3)
                {
                case 1:
                    Gui_DrawFont_GBK16(142+Sub_position3*8,47,BLACK,GRAY0,"0");
                    SubSel3.frequency_MAX*=10;
                    SubSel3.frequency_MAX+=1;
                    break;
                case 2:
                    Gui_DrawFont_GBK16(142+Sub_position3*8,87,BLACK,GRAY0,"0");
                    SubSel3.frequency_MIN*=10;
                    SubSel3.frequency_MIN+=1;
                    break;
                case 0:
                    Gui_DrawFont_GBK16(142+Sub_position3*8,167,BLACK,GRAY0,"0");
                    SubSel3.step*=10;
                    SubSel3.step+=1;
                    break;
                default:break;
                }
                if(Sub_position3<9)
                    Sub_position3++;
            }
            if(SubSel_Flag==4)
            {
                switch(Sub_Flag4%3)
                {
                case 1:Gui_DrawFont_GBK16(142+Sub_position4*8,47,BLACK,GRAY0,"0");break;
                case 2:Gui_DrawFont_GBK16(142+Sub_position4*8,87,BLACK,GRAY0,"0");break;
                case 0:
                    Gui_DrawFont_GBK16(142+Sub_position4*8,167,BLACK,GRAY0,"0");
                    SubSel3.step*=10;
                    SubSel3.step+=1;
                    break;
                default:break;
                }
                if(Sub_position4<9)
                    Sub_position4++;
            }

        }
}
void Key1Fun(void)
{
    if(MenuFlag==1)
    {
        if(SubSel_Flag==1)
        {
            switch(Sub_Flag1%4)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position1*8,67,BLACK,GRAY0,"1");
                //�����ۼ�
                SubSel1.frequency_1*=10;
                SubSel1.frequency_1+=1;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position1*8,107,BLACK,GRAY0,"1");
                //��λ���
                SubSel1.phase_1*=10;
                SubSel1.phase_1+=1;
                break;
            case 3:
                Gui_DrawFont_GBK16(142+Sub_position1*8,147,BLACK,GRAY0,"1");
                SubSel1.frequency_2*=10;
                SubSel1.frequency_2+=1;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position1*8,187,BLACK,GRAY0,"1");
                if(Sub_position1<=2)
                {
                    SubSel1.phase_2*=10;
                    SubSel1.phase_2+=1;
                }
                break;
            default:break;
            }

            //�����жϸ���������ĳ���  Ƶ�����볤����9 ��λ�ĳ�����3
            if(Sub_Flag1%4==0||Sub_Flag1%4==2){
                if(Sub_position1<2)
                    Sub_position1++;}
            else
            {
                if(Sub_position1<=9)
                    Sub_position1++;
            }
        }
        //�Ӳ˵�������
        if(SubSel_Flag==2)
        {
            Gui_DrawFont_GBK16(142+Sub_position2*8,87,BLACK,GRAY0,"1");
            if(Sub_position2<9)
            {
                Val1*=10;
                Val1+=1;
                Sub_position2++;
            }
        }
        if(SubSel_Flag==3)
        {
            switch(Sub_Flag3%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position3*8,47,BLACK,GRAY0,"1");
                SubSel3.frequency_MAX*=10;
                SubSel3.frequency_MAX+=1;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position3*8,87,BLACK,GRAY0,"1");
                SubSel3.frequency_MIN*=10;
                SubSel3.frequency_MIN+=1;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position3*8,167,BLACK,GRAY0,"1");
                SubSel3.step*=10;
                SubSel3.step+=1;
                break;
            default:break;
            }
            if(Sub_position3<9)
                Sub_position3++;
        }
        if(SubSel_Flag==4)
        {
            switch(Sub_Flag4%3)
            {
            case 1:Gui_DrawFont_GBK16(142+Sub_position4*8,47,BLACK,GRAY0,"1");break;
            case 2:Gui_DrawFont_GBK16(142+Sub_position4*8,87,BLACK,GRAY0,"1");break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position4*8,167,BLACK,GRAY0,"1");
                SubSel3.step*=10;
                SubSel3.step+=1;
                break;
            default:break;
            }
            if(Sub_position4<9)
                Sub_position4++;
        }

    }
}
void Key2Fun(void)
{
    LED2_ON;
    if(MenuFlag==1)
    {
        if(SubSel_Flag==1)
        {
            switch(Sub_Flag1%4)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position1*8,67,BLACK,GRAY0,"2");
                SubSel1.frequency_1*=10;
                SubSel1.frequency_1+=2;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position1*8,107,BLACK,GRAY0,"2");
                SubSel1.phase_1*=10;
                SubSel1.phase_1+=2;
                break;
            case 3:
                Gui_DrawFont_GBK16(142+Sub_position1*8,147,BLACK,GRAY0,"2");
                SubSel1.frequency_2*=10;
                SubSel1.frequency_2+=2;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position1*8,187,BLACK,GRAY0,"2");
                SubSel1.phase_2*=10;
                SubSel1.phase_2+=2;
                break;
            default:break;
            }
            //�����жϸ���������ĳ���  Ƶ�����볤����9 ��λ�ĳ�����3
            if(Sub_Flag1%4==0||Sub_Flag1%4==2){
                if(Sub_position1<2)
                    Sub_position1++;}
            else
            {
                if(Sub_position1<=9)
                    Sub_position1++;
            }
        }
        if(SubSel_Flag==2)
        {
            Gui_DrawFont_GBK16(142+Sub_position2*8,87,BLACK,GRAY0,"2");
            if(Sub_position2<9){
                Val1*=10;
                Val1+=2;
                Sub_position2++;}
        }
        if(SubSel_Flag==3)
        {
            switch(Sub_Flag3%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position3*8,47,BLACK,GRAY0,"2");
                SubSel3.frequency_MAX*=10;
                SubSel3.frequency_MAX+=2;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position3*8,87,BLACK,GRAY0,"2");
                SubSel3.frequency_MIN*=10;
                SubSel3.frequency_MIN+=2;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position3*8,167,BLACK,GRAY0,"2");
                SubSel3.step*=10;
                SubSel3.step+=2;
                break;
            default:break;
            }
            if(Sub_position3<9)
                Sub_position3++;
        }
        if(SubSel_Flag==4)
        {
            switch(Sub_Flag4%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position4*8,47,BLACK,GRAY0,"2");
                SubSel4.frequency_MAX*=10;
                SubSel4.frequency_MAX+=2;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position4*8,87,BLACK,GRAY0,"2");
                SubSel3.frequency_MIN*=10;
                SubSel3.frequency_MIN+=2;
                break;
            case 0:Gui_DrawFont_GBK16(142+Sub_position4*8,167,BLACK,GRAY0,"2");
                SubSel4.step*=10;
                SubSel4.step+=2;
                break;

            default:break;
            }
            if(Sub_position4<9)
                Sub_position4++;
        }
    }
}
void Key3Fun(void)
{
    LED2_ON;
    if(MenuFlag==1)
    {
        if(SubSel_Flag==1)
        {
            switch(Sub_Flag1%4)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position1*8,67,BLACK,GRAY0,"3");
                if(Sub_position1<9)
                SubSel1.frequency_1*=10;
                SubSel1.frequency_1+=3;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position1*8,107,BLACK,GRAY0,"3");
                SubSel1.phase_1*=10;
                SubSel1.phase_1+=3;
                break;
            case 3:
                Gui_DrawFont_GBK16(142+Sub_position1*8,147,BLACK,GRAY0,"3");
                SubSel1.frequency_2*=10;
                SubSel1.frequency_2+=3;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position1*8,187,BLACK,GRAY0,"3");
                if(Sub_position1<2)
                {
                    SubSel1.phase_2*=10;
                    SubSel1.phase_2+=3;
                }
                break;
            default:break;
            }
            //�����жϸ���������ĳ���  Ƶ�����볤����9 ��λ�ĳ�����3
            if(Sub_Flag1%4==0||Sub_Flag1%4==2)
            {
                if(Sub_position1<2)
                    Sub_position1++;
            }
            else
            {
                if(Sub_position1<=9)
                    Sub_position1++;
            }
        }
        if(SubSel_Flag==2)
        {
            Gui_DrawFont_GBK16(142+Sub_position2*8,87,BLACK,GRAY0,"3");
            if(Sub_position2<9){
                Val1*=10;
                Val1+=3;
                Sub_position2++;}
        }
        if(SubSel_Flag==3)
        {
            switch(Sub_Flag3%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position3*8,47,BLACK,GRAY0,"3");
                SubSel3.frequency_MAX*=10;
                SubSel3.frequency_MAX+=3;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position3*8,87,BLACK,GRAY0,"3");
                SubSel3.frequency_MIN*=10;
                SubSel3.frequency_MIN+=3;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position3*8,167,BLACK,GRAY0,"3");
                SubSel3.step*=10;
                SubSel3.step+=3;
                break;
            default:break;
            }
            if(Sub_position3<9)
                Sub_position3++;
        }
        if(SubSel_Flag==4)
        {
            switch(Sub_Flag4%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position4*8,47,BLACK,GRAY0,"3");
                SubSel4.frequency_MAX*=10;
                SubSel4.frequency_MAX+=3;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position4*8,87,BLACK,GRAY0,"3");
                SubSel4.frequency_MIN*=10;
                SubSel4.frequency_MIN+=3;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position4*8,167,BLACK,GRAY0,"3");
                SubSel4.step*=10;
                SubSel4.step+=3;
                break;
            default:break;
            }
            if(Sub_position4<9)
                Sub_position4++;
        }
    }
}

void Key4Fun(void)
{
    LED3_ON;
    if(MenuFlag==1)
    {
        if(SubSel_Flag==1)
        {
            switch(Sub_Flag1%4)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position1*8,67,BLACK,GRAY0,"4");
                SubSel1.frequency_1*=10;
                SubSel1.frequency_1+=4;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position1*8,107,BLACK,GRAY0,"4");
                SubSel1.phase_1*=10;
                SubSel1.phase_1+=4;
                break;
            case 3:
                Gui_DrawFont_GBK16(142+Sub_position1*8,147,BLACK,GRAY0,"4");
                SubSel1.frequency_2*=10;
                SubSel1.frequency_2+=4;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position1*8,187,BLACK,GRAY0,"4");
                SubSel1.phase_2*=10;
                SubSel1.phase_2+=4;
                break;
            default:break;
            }
            //�����жϸ���������ĳ���  Ƶ�����볤����9 ��λ�ĳ�����3
            if(Sub_Flag1%4==0||Sub_Flag1%4==2){
                if(Sub_position1<2)
                    Sub_position1++;}
            else
            {
                if(Sub_position1<=9)
                    Sub_position1++;
            }
        }
        if(SubSel_Flag==2)
        {
            Gui_DrawFont_GBK16(142+Sub_position2*8,87,BLACK,GRAY0,"4");
            if(Sub_position2<9)
            {
                Val1*=10;
                Val1+=2;
                Sub_position2++;
            }
        }
        if(SubSel_Flag==3)
        {
            switch(Sub_Flag3%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position3*8,47,BLACK,GRAY0,"4");
                SubSel3.frequency_MAX*=10;
                SubSel3.frequency_MAX+=4;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position3*8,87,BLACK,GRAY0,"4");
                SubSel3.frequency_MIN*=10;
                SubSel3.frequency_MIN+=4;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position3*8,167,BLACK,GRAY0,"4");
                SubSel3.step*=10;
                SubSel3.step+=4;
                break;
            default:break;
            }
            if(Sub_position3<9)
            {
                Val1*=10;
                Val1+=4;
                Sub_position3++;
            }
        }
        if(SubSel_Flag==4)
        {
            switch(Sub_Flag4%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position4*8,47,BLACK,GRAY0,"4");
                SubSel4.frequency_MAX*=10;
                SubSel4.frequency_MAX+=1;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position4*8,87,BLACK,GRAY0,"4");
                SubSel4.frequency_MIN*=10;
                SubSel4.frequency_MIN+=4;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position4*8,167,BLACK,GRAY0,"4");
                SubSel4.step*=10;
                SubSel4.step+=4;
                break;
            default:break;
            }
            if(Sub_position4<9)
                Sub_position4++;
        }
    }
}

void Key5Fun(void)
{
    LED3_ON;
    if(MenuFlag==1)
    {
        if(SubSel_Flag==1)
        {
            switch(Sub_Flag1%4)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position1*8,67,BLACK,GRAY0,"5");
                SubSel1.frequency_1*=10;
                SubSel1.frequency_1+=5;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position1*8,107,BLACK,GRAY0,"5");
                SubSel1.phase_1*=10;
                SubSel1.phase_1+=5;
                break;
            case 3:
                Gui_DrawFont_GBK16(142+Sub_position1*8,147,BLACK,GRAY0,"5");
                SubSel1.frequency_2*=10;
                SubSel1.frequency_2+=5;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position1*8,187,BLACK,GRAY0,"5");
                SubSel1.phase_2*=10;
                SubSel1.phase_2+=5;
                break;
            default:break;
            }
            //�����жϸ���������ĳ���  Ƶ�����볤����9 ��λ�ĳ�����3
            if(Sub_Flag1%4==0||Sub_Flag1%4==2){
                if(Sub_position1<2)
                    Sub_position1++;}
            else
            {
                if(Sub_position1<=9)
                    Sub_position1++;
            }
        }
        if(SubSel_Flag==2)
        {
            Gui_DrawFont_GBK16(142+Sub_position2*8,87,BLACK,GRAY0,"5");
            if(Sub_position2<9)
            {
                Val1*=10;
                Val1+=5;
                Sub_position2++;
            }
        }
        if(SubSel_Flag==3)
        {
            switch(Sub_Flag3%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position3*8,47,BLACK,GRAY0,"5");
                SubSel3.frequency_MAX*=10;
                SubSel3.frequency_MAX+=1;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position3*8,87,BLACK,GRAY0,"5");
                SubSel3.frequency_MIN*=10;
                SubSel3.frequency_MIN+=5;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position3*8,167,BLACK,GRAY0,"5");
                SubSel3.step*=10;
                SubSel3.step+=5;
                break;
            default:break;
            }
            if(Sub_position3<9)
                Sub_position3++;
        }
        if(SubSel_Flag==4)
        {
            switch(Sub_Flag4%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position4*8,47,BLACK,GRAY0,"5");
                SubSel4.frequency_MAX*=10;
                SubSel4.frequency_MAX+=5;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position4*8,87,BLACK,GRAY0,"5");
                SubSel4.frequency_MIN*=10;
                SubSel4.frequency_MIN+=5;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position4*8,167,BLACK,GRAY0,"5");
                SubSel4.step*=10;
                SubSel4.step+=5;
                break;
            default:break;
            }
            if(Sub_position4<9)
                Sub_position4++;
        }
    }


}
void Key6Fun(void)
{
    LED4_ON;
    if(MenuFlag==1)
    {
        if(SubSel_Flag==1)
        {
            switch(Sub_Flag1%4)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position1*8,67,BLACK,GRAY0,"6");
                SubSel1.frequency_1*=10;
                SubSel1.frequency_1+=6;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position1*8,107,BLACK,GRAY0,"6");
                SubSel1.phase_1*=10;
                SubSel1.phase_1+=6;
                break;
            case 3:
                Gui_DrawFont_GBK16(142+Sub_position1*8,147,BLACK,GRAY0,"6");
                SubSel1.frequency_2*=10;
                SubSel1.frequency_2+=6;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position1*8,187,BLACK,GRAY0,"6");
                SubSel1.phase_2*=10;
                SubSel1.phase_2+=6;
                break;
            default:break;
            }
            //�����жϸ���������ĳ���  Ƶ�����볤����9 ��λ�ĳ�����3
            if(Sub_Flag1%4==0||Sub_Flag1%4==2){
                if(Sub_position1<2)
                    Sub_position1++;}
            else
            {
                if(Sub_position1<=9)
                    Sub_position1++;
            }
        }
        if(SubSel_Flag==2)
        {
            Gui_DrawFont_GBK16(142+Sub_position2*8,87,BLACK,GRAY0,"6");
            if(Sub_position2<9)
            {
                Val1*=10;
                Val1+=6;
                Sub_position2++;
            }
        }
        if(SubSel_Flag==3)
        {
            switch(Sub_Flag3%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position3*8,47,BLACK,GRAY0,"6");
                SubSel3.frequency_MAX*=10;
                SubSel3.frequency_MAX+=6;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position3*8,87,BLACK,GRAY0,"6");
                SubSel3.frequency_MIN*=10;
                SubSel3.frequency_MIN+=6;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position3*8,167,BLACK,GRAY0,"6");
                SubSel3.step*=10;
                SubSel3.step+=6;
                break;
            default:break;
            }
            if(Sub_position3<9)
                Sub_position3++;
        }
        if(SubSel_Flag==4)
        {
            switch(Sub_Flag4%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position4*8,47,BLACK,GRAY0,"6");
                SubSel4.frequency_MAX*=10;
                SubSel4.frequency_MAX+=6;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position4*8,87,BLACK,GRAY0,"6");
                SubSel4.frequency_MIN*=10;
                SubSel4.frequency_MIN+=6;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position4*8,167,BLACK,GRAY0,"6");
                SubSel4.step*=10;
                SubSel4.step+=6;
                break;
            default:break;
            }
            if(Sub_position4<9)
                Sub_position4++;
        }
    }
}
void Key7Fun(void)
{
    LED4_ON;
    if(MenuFlag==1)
    {
        if(SubSel_Flag==1)
        {
            switch(Sub_Flag1%4)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position1*8,67,BLACK,GRAY0,"7");
                SubSel1.frequency_1*=10;
                SubSel1.frequency_1+=7;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position1*8,107,BLACK,GRAY0,"7");
                SubSel1.phase_1*=10;
                SubSel1.phase_1+=7;
                break;
            case 3:
                Gui_DrawFont_GBK16(142+Sub_position1*8,147,BLACK,GRAY0,"7");
                SubSel1.frequency_2*=10;
                SubSel1.frequency_2+=7;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position1*8,187,BLACK,GRAY0,"7");
                SubSel1.phase_2*=10;
                SubSel1.phase_2+=7;
                break;
            default:break;
            }
            //�����жϸ���������ĳ���  Ƶ�����볤����9 ��λ�ĳ�����3
            if(Sub_Flag1%4==0||Sub_Flag1%4==2){
                if(Sub_position1<2)
                    Sub_position1++;}
            else
            {
                if(Sub_position1<=9)
                    Sub_position1++;
            }
        }
        if(SubSel_Flag==2)
        {
            Gui_DrawFont_GBK16(142+Sub_position2*8,87,BLACK,GRAY0,"7");
            if(Sub_position2<9)
            {
                Val1*=10;
                Val1+=7;
                Sub_position2++;
            }
        }
        if(SubSel_Flag==3)
        {
            switch(Sub_Flag3%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position3*8,47,BLACK,GRAY0,"7");
                SubSel3.frequency_MAX*=10;
                                SubSel3.frequency_MAX+=7;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position3*8,87,BLACK,GRAY0,"7");
                SubSel3.frequency_MIN*=10;
                               SubSel3.frequency_MIN+=7;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position3*8,167,BLACK,GRAY0,"7");
                SubSel3.step*=10;
                SubSel3.step+=7;
                break;
            default:break;
            }
            if(Sub_position3<9)
                Sub_position3++;
        }
        if(SubSel_Flag==4)
        {
            switch(Sub_Flag4%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position4*8,47,BLACK,GRAY0,"7");
                SubSel4.frequency_MAX*=10;
                SubSel4.frequency_MAX+=7;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position4*8,87,BLACK,GRAY0,"7");
                SubSel4.frequency_MIN*=10;
                SubSel4.frequency_MIN+=7;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position4*8,167,BLACK,GRAY0,"7");
                SubSel4.step*=10;
                SubSel4.step+=7;
                break;
            default:break;
            }
            if(Sub_position4<9)
                Sub_position4++;
        }
    }
}
void Key8Fun(void)
{
    LED5_ON;
    if(MenuFlag==1)
    {
        if(SubSel_Flag==1)
        {
            switch(Sub_Flag1%4)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position1*8,67,BLACK,GRAY0,"8");
                SubSel1.frequency_1*=10;
                SubSel1.frequency_1+=8;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position1*8,107,BLACK,GRAY0,"8");
                SubSel1.phase_1*=10;
                SubSel1.phase_1+=8;
                break;
            case 3:
                Gui_DrawFont_GBK16(142+Sub_position1*8,147,BLACK,GRAY0,"8");
                SubSel1.frequency_2*=10;
                SubSel1.frequency_2+=8;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position1*8,187,BLACK,GRAY0,"8");
                SubSel1.phase_2*=10;
                SubSel1.phase_2+=8;
                break;
            default:break;
            }
            //�����жϸ���������ĳ���  Ƶ�����볤����9 ��λ�ĳ�����3
            if(Sub_Flag1%4==0||Sub_Flag1%4==2){
                if(Sub_position1<2)
                    Sub_position1++;}
            else
            {
                if(Sub_position1<=9)
                    Sub_position1++;
            }
        }
        if(SubSel_Flag==2)
        {
            Gui_DrawFont_GBK16(142+Sub_position2*8,87,BLACK,GRAY0,"8");
            if(Sub_position2<9)
            {
                Val1*=10;
                Val1+=8;
                Sub_position2++;
            }
        }
        if(SubSel_Flag==3)
        {
            switch(Sub_Flag3%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position3*8,47,BLACK,GRAY0,"8");
                SubSel3.frequency_MAX*=10;
                SubSel3.frequency_MAX+=1;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position3*8,87,BLACK,GRAY0,"8");
                SubSel3.frequency_MIN*=10;
                SubSel3.frequency_MIN+=8;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position3*8,167,BLACK,GRAY0,"8");
                SubSel3.step*=10;
                SubSel3.step+=8;
                break;
            default:break;
            }
            if(Sub_position3<9)
                Sub_position3++;
        }
        if(SubSel_Flag==4)
        {
            switch(Sub_Flag4%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position4*8,47,BLACK,GRAY0,"8");
                SubSel4.frequency_MAX*=10;
                SubSel4.frequency_MAX+=8;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position4*8,87,BLACK,GRAY0,"8");
                SubSel4.frequency_MIN*=10;
                SubSel4.frequency_MIN+=8;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position4*8,167,BLACK,GRAY0,"8");
                SubSel4.step*=10;
                SubSel4.step+=8;
                break;
            default:break;
            }
            if(Sub_position4<9)
                Sub_position4++;
        }
    }
}
void Key9Fun(void)
{
    LED5_ON;
    if(MenuFlag==1)
    {
        if(SubSel_Flag==1)
        {
            switch(Sub_Flag1%4)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position1*8,67,BLACK,GRAY0,"9");
                SubSel1.frequency_1*=10;
                SubSel1.frequency_1+=9;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position1*8,107,BLACK,GRAY0,"9");
                SubSel1.phase_1*=10;
                SubSel1.phase_1+=8;
                break;
            case 3:
                Gui_DrawFont_GBK16(142+Sub_position1*8,147,BLACK,GRAY0,"9");
                SubSel1.frequency_2*=10;
                SubSel1.frequency_2+=9;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position1*8,187,BLACK,GRAY0,"9");
                SubSel1.phase_2*=10;
                SubSel1.phase_2+=9;
                break;
            default:break;
            }
            //�����жϸ���������ĳ���  Ƶ�����볤����9 ��λ�ĳ�����3
            if(Sub_Flag1%4==0||Sub_Flag1%4==2){
                if(Sub_position1<2)
                    Sub_position1++;}
            else
            {
                if(Sub_position1<=9)
                    Sub_position1++;
            }
        }
        if(SubSel_Flag==2)
        {
            Gui_DrawFont_GBK16(142+Sub_position2*8,87,BLACK,GRAY0,"9");
            if(Sub_position2<9)
            {
                Val1*=10;
                Val1+=9;
                Sub_position2++;
            }
        }
        if(SubSel_Flag==3)
        {
            switch(Sub_Flag3%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position3*8,47,BLACK,GRAY0,"9");
                SubSel3.frequency_MAX*=10;
                SubSel3.frequency_MAX+=9;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position3*8,87,BLACK,GRAY0,"9");
                SubSel3.frequency_MIN*=10;
                SubSel3.frequency_MIN+=9;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position3*8,167,BLACK,GRAY0,"9");
                SubSel3.step*=10;
                SubSel3.step+=9;
                break;
            default:break;
            }
            if(Sub_position3<9)
                Sub_position3++;
        }
        if(SubSel_Flag==4)
        {
            switch(Sub_Flag4%3)
            {
            case 1:
                Gui_DrawFont_GBK16(142+Sub_position4*8,47,BLACK,GRAY0,"9");
                SubSel4.frequency_MAX*=10;
                SubSel4.frequency_MAX+=9;
                break;
            case 2:
                Gui_DrawFont_GBK16(142+Sub_position4*8,87,BLACK,GRAY0,"9");
                SubSel4.frequency_MIN*=10;
                SubSel4.frequency_MIN+=9;
                break;
            case 0:
                Gui_DrawFont_GBK16(142+Sub_position4*8,167,BLACK,GRAY0,"9");
                SubSel3.step*=10;
                SubSel3.step+=9;
                break;
            default:break;
            }
            if(Sub_position4<9)
                Sub_position4++;
        }
    }
}

void Key10Fun(void)
{
    Sub_position1=0;    //�����������ʼλ��
    Sub_position4=0;
    Sub_position2=0;
    Sub_position3=0;
    LED6_ON;
    //���˵�����ѡ���л�  SubSle_Flag�ɱ�ʾ�ӹ��ܲ˵���Ŀ
    if(MenuFlag==0)
    {
        SubSel_Flag%=4;
        SubSel_Flag++;     //SubSle_Flag��1,2,3,4���л�
        switch(SubSel_Flag)
        {
        case 1: ClearButtonUp(79,166,177,192,GRAY0);    //   ���4
                DisplayButtonUp(79,46,177,72);          //   ��ʾ1
                break;
        case 2: ClearButtonUp(79,46,177,72,GRAY0);      //   ���1
                DisplayButtonUp(79,86,177,112);         //   ��ʾ2
                break;
        case 3: ClearButtonUp(79,86,177,112,GRAY0);     //   ���2
                DisplayButtonUp(79,126,177,152);        //   ��ʾ3
                break;
        case 4: ClearButtonUp(79,126,177,152,GRAY0);    //   ���3
                DisplayButtonUp(79,166,177,192);        //   ��ʾ4
                break;
        }
    }
    //�����Ӳ˵�1 ������ֵ����ѡ���л�
    if((MenuFlag==1)&&(SubSel_Flag==1))
    {
        Sub_Flag1%=4;
        Sub_Flag1++;
        switch(Sub_Flag1)
        {
        case 1: ClearButtonUp(139,179,281,205,GRAY0);    //���4
                DisplayButtonUp(139,59,281,85);          //��ʾ1
                break;
        case 2: ClearButtonUp(139,59,281,85,GRAY0);      //���1
                DisplayButtonUp(139,99,281,125);         //��ʾ2
                break;
        case 3: ClearButtonUp(139,99,281,125,GRAY0);      //���2
                DisplayButtonUp(139,139,281,165);         //��ʾ3
                break;
        case 4: ClearButtonUp(139,139,281,165,GRAY0);     //���3
                DisplayButtonUp(139,179,281,205);          //��ʾ4
                break;
        }
    }
    //�����Ӳ˵�2 ������ֵ����ѡ���л�
        if((MenuFlag==1)&&(SubSel_Flag==2))
        {
            Sub_Flag2%=3;
            Sub_Flag2++;
            switch(Sub_Flag2)
            {
            case 1: ClearButtonUp(139,199,281,225,GRAY0);    //���4
                    DisplayButtonUp(139,79,281,105); //x1,y1,x2,y2
            break;
            case 2: ClearButtonUp(139,79,281,105,GRAY0);      //���1
                    DisplayButtonUp(139,159,281,185); //x1,y1,x2,y2
            break;
            case 3: ClearButtonUp(139,159,281,185,GRAY0);      //���2
                    DisplayButtonUp(139,199,281,225); //x1,y1,x2,y2
            break;
            }
        }
    //�����Ӳ˵�3 ������ֵ����ѡ���л�
    if((MenuFlag==1)&&(SubSel_Flag==3))
    {
        Sub_Flag3%=3;
        Sub_Flag3++;
        switch(Sub_Flag3)
        {
        case 1: ClearButtonUp(139,159,281,185,GRAY0);    //���3
                DisplayButtonUp(139,39,281,65);           //��ʾ1
                break;
        case 2: ClearButtonUp(139,39,281,65,GRAY0);        //���1
                DisplayButtonUp(139,79,281,105);          //��ʾ2
                break;
        case 3: ClearButtonUp(139,79,281,105,GRAY0);      //���2
                DisplayButtonUp(139,159,281,185);        //��ʾ3
                break;
        }
    }
    //�����Ӳ˵�4 ������ֵ����ѡ���л�
    if((MenuFlag==1)&&(SubSel_Flag==4))
    {
        Sub_Flag4%=3;
        Sub_Flag4++;
        switch(Sub_Flag4)
        {
        case 1: ClearButtonUp(139,159,281,185,GRAY0);    //���3
                DisplayButtonUp(139,39,281,65);           //��ʾ1
                break;
        case 2: ClearButtonUp(139,39,281,65,GRAY0);        //���1
                DisplayButtonUp(139,79,281,105);          //��ʾ2
                break;
        case 3: ClearButtonUp(139,79,281,105,GRAY0);      //���2
                DisplayButtonUp(139,159,281,185);        //��ʾ3
                break;
        }
    }
}
void Key11Fun(void)
{
    LED6_ON;
    Sub_position1=0;    //�����������ʼλ��
    Sub_position4=0;
    Sub_position3=0;
    Sub_position2=0;
    if(MenuFlag==0)
    {
        SubSel_Flag--;
        if(SubSel_Flag==0||SubSel_Flag>5)
        {
            SubSel_Flag=4;
        }
        switch(SubSel_Flag)
        {
        case 1: ClearButtonUp(79,86,177,112,GRAY0);
                DisplayButtonUp(79,46,177,72);
                break;
        case 2: ClearButtonUp(79,126,177,152,GRAY0);
                DisplayButtonUp(79,86,177,112);
                break;
        case 3: ClearButtonUp(79,166,177,192,GRAY0);
                DisplayButtonUp(79,126,177,152);
                break;
        case 4: ClearButtonUp(79,46,177,72,GRAY0);
                DisplayButtonUp(79,166,177,192);
                break;
        }
    }
    if((MenuFlag==1)&&(SubSel_Flag==1))
    {
        Sub_Flag1--;
        if(Sub_Flag1==0||Sub_Flag1>5)
        {
            Sub_Flag1=4;
        }
        switch(Sub_Flag1)
        {
        case 1: ClearButtonUp(139,99,281,125,GRAY0);     //���2
                DisplayButtonUp(139,59,281,85);          //��ʾ1
                break;
        case 2: ClearButtonUp(139,139,281,165,GRAY0);    //���3
                DisplayButtonUp(139,99,281,125);         //��ʾ2
                break;
        case 3: ClearButtonUp(139,179,281,205,GRAY0);    //���4
                DisplayButtonUp(139,139,281,165);        //��ʾ3
                break;
        case 4: ClearButtonUp(139,59,281,85,GRAY0);     //���1
                DisplayButtonUp(139,179,281,205);       //��ʾ4
                break;
        }
    }

    //�˵�2�л������
    if((MenuFlag==1)&&(SubSel_Flag==2))
        {
            Sub_Flag2--;
            if(Sub_Flag2==0||Sub_Flag2>5)
            {
                Sub_Flag2=3;
            }
            switch(Sub_Flag2)
            {
            case 1: ClearButtonUp(139,159,281,185,GRAY0);     //���2
                    DisplayButtonUp(139,79,281,105); //x1,y1,x2,y2
                    break;
            case 2: ClearButtonUp(139,199,281,225,GRAY0);    //���3
                    DisplayButtonUp(139,159,281,185); //x1,y1,x2,y2
                    break;
            case 3: ClearButtonUp(139,79,281,105,GRAY0);    //���4
                    DisplayButtonUp(139,199,281,225); //x1,y1,x2,y2
                    break;
            }
        }
    //�����Ӳ˵�3 ������ֵ����ѡ���л�
    if((MenuFlag==1)&&(SubSel_Flag==3))
    {
        Sub_Flag3--;
        if(Sub_Flag3==0||Sub_Flag3>3)
        {
            Sub_Flag3=3;
        }
        switch(Sub_Flag3)
        {
        case 1: ClearButtonUp(139,79,281,105,GRAY0);      //���2
                DisplayButtonUp(139,39,281,65);           //��ʾ1
                break;
        case 2: ClearButtonUp(139,159,281,185,GRAY0);    //���3
                DisplayButtonUp(139,79,281,105);          //��ʾ2
                break;
        case 3: ClearButtonUp(139,39,281,65,GRAY0);        //���1
                DisplayButtonUp(139,159,281,185);        //��ʾ3
                break;
        }
    }
    //�����Ӳ˵�4 ������ֵ����ѡ���л�
    if((MenuFlag==1)&&(SubSel_Flag==4))
    {
        Sub_Flag4--;
        if(Sub_Flag4==0||Sub_Flag4>3)
        {
            Sub_Flag4=3;
        }
        switch(Sub_Flag4)
        {
        case 1: ClearButtonUp(139,79,281,105,GRAY0);      //���2
                DisplayButtonUp(139,39,281,65);           //��ʾ1
                break;
        case 2: ClearButtonUp(139,159,281,185,GRAY0);    //���3
                DisplayButtonUp(139,79,281,105);          //��ʾ2
                break;
        case 3: ClearButtonUp(139,39,281,65,GRAY0);        //���1
                DisplayButtonUp(139,159,281,185);        //��ʾ3
                break;
        }
    }
}
void Key12Fun(void)
{
    LED7_ON;
}
void Key13Fun(void)
{
    LED7_ON;
    if(MenuFlag==1)
    {
        Draw_Mainmenu();
        SubSel_Flag=0;
        Sub_Flag1=0;
        Sub_Flag2=0;
        Sub_Flag3=0;
        Sub_Flag4=0;
    }
    MenuFlag=0;
}
void Key14Fun(void)
{
    LED8_ON;
}
void Key15Fun(void)
{
    LED8_ON;
    if(MenuFlag==0)
    {
        switch(SubSel_Flag)
        {
        case 1: Draw_Submenu1();break;
        case 2: Draw_Submenu2();break;
        case 3: Draw_Submenu3();break;
        case 4: Draw_Submenu4();break;
        }
        MenuFlag=1;
    }
}

unsigned char ifpressed=0;
void KeyFun(void)
{
    switch(Key)
    {
    case 0: if(!ifpressed)Key0Fun();ifpressed=1;break;
    case 1: if(!ifpressed)Key1Fun();ifpressed=1;break;
    case 2: if(!ifpressed)Key2Fun();ifpressed=1;break;
    case 3: if(!ifpressed)Key3Fun();ifpressed=1;break;
    case 4: if(!ifpressed)Key4Fun();ifpressed=1;break;
    case 5: if(!ifpressed)Key5Fun();ifpressed=1;break;
    case 6: if(!ifpressed)Key6Fun();ifpressed=1;break;
    case 7: if(!ifpressed)Key7Fun();ifpressed=1;break;
    case 8: if(!ifpressed)Key8Fun();ifpressed=1;break;
    case 9: if(!ifpressed)Key9Fun();ifpressed=1;break;
    case 10: if(!ifpressed)Key10Fun();ifpressed=1;break;
    case 11: if(!ifpressed)Key11Fun();ifpressed=1;break;
    case 12: if(!ifpressed)Key12Fun();ifpressed=1;break;
    case 13: if(!ifpressed)Key13Fun();ifpressed=1;break;
    case 14: if(!ifpressed)Key14Fun();ifpressed=1;break;
    case 15: if(!ifpressed)Key15Fun();ifpressed=1;break;
    default:
        ifpressed=0;
        LED1_OFF; LED2_OFF; LED3_OFF; LED4_OFF;
        LED5_OFF; LED6_OFF; LED7_OFF; LED8_OFF;
        break;
    }
}


//===========================================================================
// No more.
//===========================================================================

