/*
 * LCD12864.h
 *
 *  Created on: 2018-8-4
 *      Author: Administrator
 */

#ifndef LCD12864_H_
#define LCD12864_H_

extern void InitLcdGpio(void);
extern void InitLcd(void);
extern void TestLcd(void);

#endif /* LCD12864_H_ */
