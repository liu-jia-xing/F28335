/*
 * LED.h
 *
 *  Created on: 2016-10-11
 *      Author: Administrator
 */

#ifndef LED_H_
#define LED_H_

extern void InitLedGpio(void);

#endif /* LED_H_ */
