/*
 * LED.h
 *
 *  Created on: 2016-10-11
 *      Author: Administrator
 */

#ifndef LED_H_
#define LED_H_

extern void InitLedGpio(void);
extern void init_led();
#endif /* LED_H_ */
